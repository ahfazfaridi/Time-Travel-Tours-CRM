import React from 'react'
import { 
  LayoutDashboard, 
  Calendar, 
  Users, 
  MapPin, 
  BarChart3, 
  Settings,
  ChevronLeft,
  ChevronRight,
  Plane
} from 'lucide-react'
import { NavigationPage } from '../../App'

interface SidebarProps {
  currentPage: NavigationPage
  onPageChange: (page: NavigationPage) => void
  collapsed: boolean
  onToggleCollapse: () => void
}

const navigationItems = [
  { id: 'dashboard' as NavigationPage, label: 'Dashboard', icon: LayoutDashboard },
  { id: 'bookings' as NavigationPage, label: 'Booking Management', icon: Calendar },
  { id: 'customers' as NavigationPage, label: 'Customer Relations', icon: Users },
  { id: 'itineraries' as NavigationPage, label: 'Itinerary Planning', icon: MapPin },
  { id: 'analytics' as NavigationPage, label: 'Analytics & Reports', icon: BarChart3 },
  { id: 'settings' as NavigationPage, label: 'Settings', icon: Settings },
]

export const Sidebar: React.FC<SidebarProps> = ({
  currentPage,
  onPageChange,
  collapsed,
  onToggleCollapse
}) => {
  console.log('Sidebar rendering with collapsed:', collapsed, 'currentPage:', currentPage)

  return (
    <div className={`fixed left-0 top-0 h-full bg-white border-r border-border z-50 transition-all duration-300 ${
      collapsed ? 'w-16' : 'w-64'
    }`}>
      {/* Header */}
      <div className="flex items-center justify-between p-4 border-b border-border">
        {!collapsed && (
          <div className="flex items-center space-x-2">
            <div className="w-8 h-8 enterprise-gradient rounded-lg flex items-center justify-center">
              <Plane className="w-5 h-5 text-white" />
            </div>
            <div>
              <h1 className="text-lg font-bold text-foreground">TravelCEO</h1>
              <p className="text-xs text-muted-foreground">Enterprise</p>
            </div>
          </div>
        )}
        
        <button
          onClick={onToggleCollapse}
          className="p-1.5 rounded-lg hover:bg-accent transition-colors"
        >
          {collapsed ? (
            <ChevronRight className="w-4 h-4" />
          ) : (
            <ChevronLeft className="w-4 h-4" />
          )}
        </button>
      </div>

      {/* Navigation */}
      <nav className="p-2">
        <div className="space-y-1">
          {navigationItems.map((item) => {
            const IconComponent = item.icon
            const isActive = currentPage === item.id
            
            return (
              <button
                key={item.id}
                onClick={() => onPageChange(item.id)}
                className={`w-full flex items-center px-3 py-2.5 rounded-lg transition-all duration-200 ${
                  isActive
                    ? 'bg-primary text-primary-foreground shadow-sm'
                    : 'text-muted-foreground hover:text-foreground hover:bg-accent'
                } ${collapsed ? 'justify-center' : 'justify-start space-x-3'}`}
                title={collapsed ? item.label : ''}
              >
                <IconComponent className="w-5 h-5 flex-shrink-0" />
                {!collapsed && (
                  <span className="text-sm font-medium">{item.label}</span>
                )}
              </button>
            )
          })}
        </div>
      </nav>

      {/* Footer */}
      {!collapsed && (
        <div className="absolute bottom-4 left-4 right-4">
          <div className="p-3 rounded-lg bg-muted/50 border border-border">
            <div className="flex items-center space-x-2">
              <div className="w-8 h-8 rounded-full bg-corporate-blue flex items-center justify-center">
                <span className="text-xs font-medium text-white">JD</span>
              </div>
              <div className="flex-1 min-w-0">
                <p className="text-sm font-medium text-foreground truncate">John Doe</p>
                <p className="text-xs text-muted-foreground truncate">Travel Admin</p>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  )
}