import React from 'react'
import { Search, Bell, Menu, Globe, Calendar } from 'lucide-react'
import { NavigationPage } from '../../App'

interface HeaderProps {
  onToggleSidebar: () => void
  currentPage: NavigationPage
}

const pageTitle = {
  dashboard: 'Dashboard Overview',
  bookings: 'Booking Management',
  customers: 'Customer Relations',
  itineraries: 'Itinerary Planning',
  analytics: 'Analytics & Reports',
  settings: 'System Settings'
}

export const Header: React.FC<HeaderProps> = ({
  onToggleSidebar,
  currentPage
}) => {
  console.log('Header rendering for page:', currentPage)

  return (
    <header className="bg-white border-b border-border px-6 py-4">
      <div className="flex items-center justify-between">
        {/* Left section */}
        <div className="flex items-center space-x-4">
          <button
            onClick={onToggleSidebar}
            className="p-2 rounded-lg hover:bg-accent transition-colors lg:hidden"
          >
            <Menu className="w-5 h-5" />
          </button>
          
          <div>
            <h2 className="text-xl font-semibold text-foreground">
              {pageTitle[currentPage]}
            </h2>
            <p className="text-sm text-muted-foreground">
              Manage your enterprise travel operations
            </p>
          </div>
        </div>

        {/* Right section */}
        <div className="flex items-center space-x-4">
          {/* Search */}
          <div className="relative hidden md:block">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 w-4 h-4 text-muted-foreground" />
            <input
              type="text"
              placeholder="Search bookings, customers..."
              className="pl-10 pr-4 py-2 w-64 border border-input rounded-lg bg-background text-sm focus:outline-none focus:ring-2 focus:ring-ring focus:border-transparent"
            />
          </div>

          {/* Quick actions */}
          <div className="flex items-center space-x-2">
            <button className="p-2 rounded-lg hover:bg-accent transition-colors relative">
              <Globe className="w-5 h-5 text-muted-foreground" />
            </button>
            
            <button className="p-2 rounded-lg hover:bg-accent transition-colors relative">
              <Calendar className="w-5 h-5 text-muted-foreground" />
            </button>
            
            <button className="p-2 rounded-lg hover:bg-accent transition-colors relative">
              <Bell className="w-5 h-5 text-muted-foreground" />
              <div className="absolute -top-1 -right-1 w-3 h-3 bg-corporate-danger rounded-full border-2 border-white"></div>
            </button>
          </div>

          {/* User profile */}
          <div className="flex items-center space-x-3 pl-4 border-l border-border">
            <div className="w-8 h-8 rounded-full enterprise-gradient flex items-center justify-center">
              <span className="text-sm font-medium text-white">JD</span>
            </div>
            <div className="hidden sm:block">
              <p className="text-sm font-medium text-foreground">John Doe</p>
              <p className="text-xs text-muted-foreground">Travel Administrator</p>
            </div>
          </div>
        </div>
      </div>
    </header>
  )
}