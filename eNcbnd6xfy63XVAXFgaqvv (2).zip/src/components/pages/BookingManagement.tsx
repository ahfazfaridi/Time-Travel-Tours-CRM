import React, { useState } from 'react'
import { 
  Search, 
  Filter, 
  Plus, 
  Download, 
  Calendar, 
  MapPin, 
  User,
  DollarSign,
  Clock,
  CheckCircle,
  XCircle,
  AlertCircle
} from 'lucide-react'
import { Card } from '../ui/card'
import { Button } from '../ui/button'

interface Booking {
  id: string
  traveler: string
  email: string
  destination: string
  departure: string
  return: string
  status: 'approved' | 'pending' | 'rejected' | 'completed'
  amount: number
  bookingDate: string
  approver?: string
}

export const BookingManagement: React.FC = () => {
  const [searchTerm, setSearchTerm] = useState('')
  const [statusFilter, setStatusFilter] = useState('all')
  const [showNewBookingModal, setShowNewBookingModal] = useState(false)

  console.log('BookingManagement rendering with search:', searchTerm, 'filter:', statusFilter)

  const bookings: Booking[] = [
    {
      id: 'BK-2024-001',
      traveler: 'Sarah Johnson',
      email: 'sarah.johnson@company.com',
      destination: 'New York → London',
      departure: '2024-12-15',
      return: '2024-12-20',
      status: 'approved',
      amount: 2840,
      bookingDate: '2024-12-01',
      approver: 'John Smith'
    },
    {
      id: 'BK-2024-002',
      traveler: 'Michael Chen',
      email: 'michael.chen@company.com',
      destination: 'San Francisco → Tokyo',
      departure: '2024-12-18',
      return: '2024-12-25',
      status: 'pending',
      amount: 3250,
      bookingDate: '2024-12-02'
    },
    {
      id: 'BK-2024-003',
      traveler: 'Emily Davis',
      email: 'emily.davis@company.com',
      destination: 'Chicago → Paris',
      departure: '2024-12-20',
      return: '2024-12-27',
      status: 'completed',
      amount: 2150,
      bookingDate: '2024-11-28',
      approver: 'Jane Wilson'
    },
    {
      id: 'BK-2024-004',
      traveler: 'David Wilson',
      email: 'david.wilson@company.com',
      destination: 'Boston → Berlin',
      departure: '2024-12-22',
      return: '2024-12-29',
      status: 'rejected',
      amount: 1890,
      bookingDate: '2024-12-03',
      approver: 'John Smith'
    },
    {
      id: 'BK-2024-005',
      traveler: 'Lisa Anderson',
      email: 'lisa.anderson@company.com',
      destination: 'Seattle → Amsterdam',
      departure: '2024-12-25',
      return: '2025-01-02',
      status: 'approved',
      amount: 2680,
      bookingDate: '2024-12-04',
      approver: 'Jane Wilson'
    }
  ]

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'approved':
        return <CheckCircle className="w-4 h-4 text-green-600" />
      case 'pending':
        return <AlertCircle className="w-4 h-4 text-yellow-600" />
      case 'rejected':
        return <XCircle className="w-4 h-4 text-red-600" />
      case 'completed':
        return <CheckCircle className="w-4 h-4 text-blue-600" />
      default:
        return <AlertCircle className="w-4 h-4 text-gray-600" />
    }
  }

  const getStatusBadgeClass = (status: string) => {
    switch (status) {
      case 'approved':
        return 'status-badge status-approved'
      case 'pending':
        return 'status-badge status-pending'
      case 'rejected':
        return 'status-badge status-rejected'
      case 'completed':
        return 'status-badge bg-blue-100 text-blue-800'
      default:
        return 'status-badge bg-gray-100 text-gray-800'
    }
  }

  const filteredBookings = bookings.filter(booking => {
    const matchesSearch = booking.traveler.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         booking.destination.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         booking.id.toLowerCase().includes(searchTerm.toLowerCase())
    const matchesStatus = statusFilter === 'all' || booking.status === statusFilter
    return matchesSearch && matchesStatus
  })

  return (
    <div className="space-y-6">
      {/* Header Actions */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div>
          <h2 className="text-2xl font-bold text-foreground">Booking Management</h2>
          <p className="text-muted-foreground">Manage all corporate travel bookings and approvals</p>
        </div>
        
        <div className="flex items-center gap-3">
          <Button variant="outline" className="flex items-center gap-2">
            <Download className="w-4 h-4" />
            Export
          </Button>
          <Button 
            className="flex items-center gap-2"
            onClick={() => setShowNewBookingModal(true)}
          >
            <Plus className="w-4 h-4" />
            New Booking
          </Button>
        </div>
      </div>

      {/* Filters */}
      <Card className="p-6">
        <div className="flex flex-col sm:flex-row gap-4">
          <div className="relative flex-1">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 w-4 h-4 text-muted-foreground" />
            <input
              type="text"
              placeholder="Search bookings, travelers, destinations..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="pl-10 pr-4 py-2 w-full border border-input rounded-lg bg-background text-sm focus:outline-none focus:ring-2 focus:ring-ring focus:border-transparent"
            />
          </div>
          
          <div className="flex items-center gap-3">
            <div className="flex items-center gap-2">
              <Filter className="w-4 h-4 text-muted-foreground" />
              <select
                value={statusFilter}
                onChange={(e) => setStatusFilter(e.target.value)}
                className="border border-input rounded-lg px-3 py-2 text-sm bg-background focus:outline-none focus:ring-2 focus:ring-ring focus:border-transparent"
              >
                <option value="all">All Status</option>
                <option value="pending">Pending</option>
                <option value="approved">Approved</option>
                <option value="rejected">Rejected</option>
                <option value="completed">Completed</option>
              </select>
            </div>
          </div>
        </div>
      </Card>

      {/* Bookings Table */}
      <Card className="overflow-hidden">
        <div className="overflow-x-auto">
          <table className="data-table">
            <thead>
              <tr>
                <th>Booking ID</th>
                <th>Traveler</th>
                <th>Destination</th>
                <th>Travel Date</th>
                <th>Status</th>
                <th>Amount</th>
                <th>Actions</th>
              </tr>
            </thead>
            <tbody>
              {filteredBookings.map((booking) => (
                <tr key={booking.id} className="hover:bg-accent/50">
                  <td>
                    <div className="font-mono text-sm font-medium">{booking.id}</div>
                    <div className="text-xs text-muted-foreground">
                      Booked: {new Date(booking.bookingDate).toLocaleDateString()}
                    </div>
                  </td>
                  <td>
                    <div className="flex items-center space-x-3">
                      <div className="w-8 h-8 bg-primary/10 rounded-full flex items-center justify-center">
                        <User className="w-4 h-4 text-primary" />
                      </div>
                      <div>
                        <div className="font-medium">{booking.traveler}</div>
                        <div className="text-sm text-muted-foreground">{booking.email}</div>
                      </div>
                    </div>
                  </td>
                  <td>
                    <div className="flex items-center space-x-2">
                      <MapPin className="w-4 h-4 text-muted-foreground" />
                      <span className="font-medium">{booking.destination}</span>
                    </div>
                  </td>
                  <td>
                    <div className="flex items-center space-x-2">
                      <Calendar className="w-4 h-4 text-muted-foreground" />
                      <div>
                        <div className="font-medium">
                          {new Date(booking.departure).toLocaleDateString()}
                        </div>
                        <div className="text-sm text-muted-foreground">
                          to {new Date(booking.return).toLocaleDateString()}
                        </div>
                      </div>
                    </div>
                  </td>
                  <td>
                    <div className="flex items-center space-x-2">
                      {getStatusIcon(booking.status)}
                      <span className={getStatusBadgeClass(booking.status)}>
                        {booking.status.charAt(0).toUpperCase() + booking.status.slice(1)}
                      </span>
                    </div>
                    {booking.approver && (
                      <div className="text-xs text-muted-foreground mt-1">
                        by {booking.approver}
                      </div>
                    )}
                  </td>
                  <td>
                    <div className="flex items-center space-x-1">
                      <DollarSign className="w-4 h-4 text-muted-foreground" />
                      <span className="font-semibold">
                        {booking.amount.toLocaleString()}
                      </span>
                    </div>
                  </td>
                  <td>
                    <div className="flex items-center space-x-2">
                      {booking.status === 'pending' && (
                        <>
                          <Button size="sm" variant="outline" className="text-green-600 hover:text-green-700">
                            Approve
                          </Button>
                          <Button size="sm" variant="outline" className="text-red-600 hover:text-red-700">
                            Reject
                          </Button>
                        </>
                      )}
                      <Button size="sm" variant="ghost">
                        View
                      </Button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </Card>

      {/* Summary Stats */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <Card className="p-4">
          <div className="flex items-center space-x-3">
            <div className="w-10 h-10 bg-blue-100 rounded-lg flex items-center justify-center">
              <Calendar className="w-5 h-5 text-blue-600" />
            </div>
            <div>
              <p className="text-sm text-muted-foreground">Total Bookings</p>
              <p className="text-xl font-bold">{bookings.length}</p>
            </div>
          </div>
        </Card>
        
        <Card className="p-4">
          <div className="flex items-center space-x-3">
            <div className="w-10 h-10 bg-yellow-100 rounded-lg flex items-center justify-center">
              <Clock className="w-5 h-5 text-yellow-600" />
            </div>
            <div>
              <p className="text-sm text-muted-foreground">Pending</p>
              <p className="text-xl font-bold">
                {bookings.filter(b => b.status === 'pending').length}
              </p>
            </div>
          </div>
        </Card>
        
        <Card className="p-4">
          <div className="flex items-center space-x-3">
            <div className="w-10 h-10 bg-green-100 rounded-lg flex items-center justify-center">
              <CheckCircle className="w-5 h-5 text-green-600" />
            </div>
            <div>
              <p className="text-sm text-muted-foreground">Approved</p>
              <p className="text-xl font-bold">
                {bookings.filter(b => b.status === 'approved').length}
              </p>
            </div>
          </div>
        </Card>
        
        <Card className="p-4">
          <div className="flex items-center space-x-3">
            <div className="w-10 h-10 bg-primary/10 rounded-lg flex items-center justify-center">
              <DollarSign className="w-5 h-5 text-primary" />
            </div>
            <div>
              <p className="text-sm text-muted-foreground">Total Value</p>
              <p className="text-xl font-bold">
                ${bookings.reduce((sum, b) => sum + b.amount, 0).toLocaleString()}
              </p>
            </div>
          </div>
        </Card>
      </div>
    </div>
  )
}