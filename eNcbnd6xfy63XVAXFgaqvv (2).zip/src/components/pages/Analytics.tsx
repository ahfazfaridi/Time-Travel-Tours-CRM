import React, { useState } from 'react'
import { 
  BarChart3, 
  TrendingUp, 
  Download, 
  Calendar,
  DollarSign,
  Users,
  MapPin,
  Plane,
  Filter
} from 'lucide-react'
import { Card } from '../ui/card'
import { Button } from '../ui/button'

export const Analytics: React.FC = () => {
  const [dateRange, setDateRange] = useState('last-30-days')
  const [reportType, setReportType] = useState('overview')

  console.log('Analytics rendering with dateRange:', dateRange, 'reportType:', reportType)

  const kpiData = [
    {
      title: 'Total Travel Spend',
      value: '$284.5K',
      change: '+12.3%',
      trend: 'up',
      icon: DollarSign
    },
    {
      title: 'Active Travelers',
      value: '127',
      change: '+8.1%',
      trend: 'up',
      icon: Users
    },
    {
      title: 'Avg. Trip Cost',
      value: '$2,340',
      change: '-3.2%',
      trend: 'down',
      icon: Plane
    },
    {
      title: 'Top Destination',
      value: 'London',
      change: '23 trips',
      trend: 'neutral',
      icon: MapPin
    }
  ]

  const spendingData = [
    { month: 'Jul', amount: 45000 },
    { month: 'Aug', amount: 52000 },
    { month: 'Sep', amount: 48000 },
    { month: 'Oct', amount: 61000 },
    { month: 'Nov', amount: 58000 },
    { month: 'Dec', amount: 67000 }
  ]

  const destinationData = [
    { destination: 'London, UK', trips: 23, spend: 65400 },
    { destination: 'New York, USA', trips: 18, spend: 54200 },
    { destination: 'Tokyo, Japan', trips: 15, spend: 49800 },
    { destination: 'Paris, France', trips: 12, spend: 38600 },
    { destination: 'Berlin, Germany', trips: 10, spend: 32100 }
  ]

  const departmentData = [
    { department: 'Sales', spend: 89200, trips: 34 },
    { department: 'Engineering', spend: 67800, trips: 28 },
    { department: 'Marketing', spend: 45600, trips: 19 },
    { department: 'Operations', spread: 38400, trips: 16 },
    { department: 'Executive', spend: 43500, trips: 8 }
  ]

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div>
          <h2 className="text-2xl font-bold text-foreground">Analytics & Reports</h2>
          <p className="text-muted-foreground">Comprehensive travel spending and performance insights</p>
        </div>
        
        <div className="flex items-center gap-3">
          <Button variant="outline" className="flex items-center gap-2">
            <Download className="w-4 h-4" />
            Export Report
          </Button>
        </div>
      </div>

      {/* Filters */}
      <Card className="p-6">
        <div className="flex flex-col sm:flex-row gap-4">
          <div className="flex items-center gap-2">
            <Calendar className="w-4 h-4 text-muted-foreground" />
            <select
              value={dateRange}
              onChange={(e) => setDateRange(e.target.value)}
              className="border border-input rounded-lg px-3 py-2 text-sm bg-background focus:outline-none focus:ring-2 focus:ring-ring focus:border-transparent"
            >
              <option value="last-7-days">Last 7 days</option>
              <option value="last-30-days">Last 30 days</option>
              <option value="last-90-days">Last 90 days</option>
              <option value="last-year">Last year</option>
              <option value="custom">Custom range</option>
            </select>
          </div>
          
          <div className="flex items-center gap-2">
            <Filter className="w-4 h-4 text-muted-foreground" />
            <select
              value={reportType}
              onChange={(e) => setReportType(e.target.value)}
              className="border border-input rounded-lg px-3 py-2 text-sm bg-background focus:outline-none focus:ring-2 focus:ring-ring focus:border-transparent"
            >
              <option value="overview">Overview</option>
              <option value="spending">Spending Analysis</option>
              <option value="destinations">Destination Analysis</option>
              <option value="departments">Department Analysis</option>
              <option value="compliance">Policy Compliance</option>
            </select>
          </div>
        </div>
      </Card>

      {/* KPI Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        {kpiData.map((kpi, index) => {
          const IconComponent = kpi.icon
          return (
            <Card key={index} className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-muted-foreground">{kpi.title}</p>
                  <p className="text-2xl font-bold text-foreground mt-1">{kpi.value}</p>
                  <div className="flex items-center mt-2">
                    <TrendingUp className={`w-4 h-4 mr-1 ${
                      kpi.trend === 'up' ? 'text-green-600' : 
                      kpi.trend === 'down' ? 'text-red-600' : 'text-gray-600'
                    }`} />
                    <span className={`text-sm font-medium ${
                      kpi.trend === 'up' ? 'text-green-600' : 
                      kpi.trend === 'down' ? 'text-red-600' : 'text-gray-600'
                    }`}>
                      {kpi.change}
                    </span>
                  </div>
                </div>
                <div className="w-12 h-12 enterprise-gradient rounded-lg flex items-center justify-center">
                  <IconComponent className="w-6 h-6 text-white" />
                </div>
              </div>
            </Card>
          )
        })}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Spending Trend Chart */}
        <Card className="p-6">
          <div className="flex items-center justify-between mb-6">
            <h3 className="text-lg font-semibold text-foreground">Spending Trend</h3>
            <Button variant="ghost" size="sm">
              <BarChart3 className="w-4 h-4" />
            </Button>
          </div>
          
          {/* Simple bar chart representation */}
          <div className="space-y-4">
            <div className="flex items-end justify-between h-40">
              {spendingData.map((data, index) => (
                <div key={index} className="flex flex-col items-center flex-1">
                  <div 
                    className="w-8 bg-primary rounded-t-sm"
                    style={{ height: `${(data.amount / 70000) * 100}%` }}
                  />
                  <span className="text-xs text-muted-foreground mt-2">{data.month}</span>
                </div>
              ))}
            </div>
            <div className="text-center">
              <p className="text-sm text-muted-foreground">Monthly travel spending ($)</p>
            </div>
          </div>
        </Card>

        {/* Top Destinations */}
        <Card className="p-6">
          <h3 className="text-lg font-semibold text-foreground mb-6">Top Destinations</h3>
          <div className="space-y-4">
            {destinationData.map((dest, index) => (
              <div key={index} className="flex items-center justify-between">
                <div className="flex items-center space-x-3">
                  <div className="w-8 h-8 bg-primary/10 rounded-lg flex items-center justify-center">
                    <MapPin className="w-4 h-4 text-primary" />
                  </div>
                  <div>
                    <p className="font-medium text-foreground">{dest.destination}</p>
                    <p className="text-sm text-muted-foreground">{dest.trips} trips</p>
                  </div>
                </div>
                <div className="text-right">
                  <p className="font-semibold text-foreground">${(dest.spend / 1000).toFixed(0)}K</p>
                  <div className="w-16 h-2 bg-muted rounded-full mt-1">
                    <div 
                      className="h-full bg-primary rounded-full"
                      style={{ width: `${(dest.spend / 65400) * 100}%` }}
                    />
                  </div>
                </div>
              </div>
            ))}
          </div>
        </Card>
      </div>

      {/* Department Analysis */}
      <Card className="p-6">
        <div className="flex items-center justify-between mb-6">
          <h3 className="text-lg font-semibold text-foreground">Department Analysis</h3>
          <Button variant="outline" size="sm">View Details</Button>
        </div>
        
        <div className="overflow-x-auto">
          <table className="data-table">
            <thead>
              <tr>
                <th>Department</th>
                <th>Total Spend</th>
                <th>Trips</th>
                <th>Avg. per Trip</th>
                <th>Budget Usage</th>
              </tr>
            </thead>
            <tbody>
              {departmentData.map((dept, index) => (
                <tr key={index}>
                  <td>
                    <div className="font-medium">{dept.department}</div>
                  </td>
                  <td>
                    <div className="font-semibold">${dept.spend.toLocaleString()}</div>
                  </td>
                  <td>
                    <div>{dept.trips}</div>
                  </td>
                  <td>
                    <div>${Math.round(dept.spend / dept.trips).toLocaleString()}</div>
                  </td>
                  <td>
                    <div className="flex items-center space-x-2">
                      <div className="w-12 h-2 bg-muted rounded-full">
                        <div 
                          className="h-full bg-primary rounded-full"
                          style={{ width: `${Math.min((dept.spend / 100000) * 100, 100)}%` }}
                        />
                      </div>
                      <span className="text-sm text-muted-foreground">
                        {Math.round((dept.spend / 100000) * 100)}%
                      </span>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </Card>

      {/* Policy Compliance */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <Card className="p-6">
          <div className="flex items-center space-x-3 mb-4">
            <div className="w-10 h-10 bg-green-100 rounded-lg flex items-center justify-center">
              <TrendingUp className="w-5 h-5 text-green-600" />
            </div>
            <div>
              <p className="text-sm text-muted-foreground">Policy Compliance</p>
              <p className="text-2xl font-bold text-foreground">87%</p>
            </div>
          </div>
          <p className="text-sm text-muted-foreground">3% improvement vs last month</p>
        </Card>
        
        <Card className="p-6">
          <div className="flex items-center space-x-3 mb-4">
            <div className="w-10 h-10 bg-yellow-100 rounded-lg flex items-center justify-center">
              <Calendar className="w-5 h-5 text-yellow-600" />
            </div>
            <div>
              <p className="text-sm text-muted-foreground">Advance Booking</p>
              <p className="text-2xl font-bold text-foreground">72%</p>
            </div>
          </div>
          <p className="text-sm text-muted-foreground">Within 14-day policy</p>
        </Card>
        
        <Card className="p-6">
          <div className="flex items-center space-x-3 mb-4">
            <div className="w-10 h-10 bg-red-100 rounded-lg flex items-center justify-center">
              <DollarSign className="w-5 h-5 text-red-600" />
            </div>
            <div>
              <p className="text-sm text-muted-foreground">Budget Violations</p>
              <p className="text-2xl font-bold text-foreground">8</p>
            </div>
          </div>
          <p className="text-sm text-muted-foreground">Requires approval</p>
        </Card>
      </div>
    </div>
  )
}