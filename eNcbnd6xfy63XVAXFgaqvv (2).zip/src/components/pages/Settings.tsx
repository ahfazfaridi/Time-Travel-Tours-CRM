import React, { useState } from 'react'
import { 
  Settings as SettingsIcon, 
  Users, 
  Shield, 
  Bell, 
  Globe,
  CreditCard,
  Database,
  Mail,
  Smartphone,
  Lock,
  Eye,
  EyeOff,
  Save,
  RefreshCw
} from 'lucide-react'
import { Card } from '../ui/card'
import { Button } from '../ui/button'

interface SettingSection {
  id: string
  title: string
  icon: React.ReactNode
  description: string
}

export const Settings: React.FC = () => {
  const [activeSection, setActiveSection] = useState('general')
  const [showApiKey, setShowApiKey] = useState(false)
  const [notifications, setNotifications] = useState({
    email: true,
    sms: false,
    push: true,
    booking: true,
    approval: true,
    policy: false
  })

  console.log('Settings rendering with active section:', activeSection)

  const settingSections: SettingSection[] = [
    {
      id: 'general',
      title: 'General Settings',
      icon: <SettingsIcon className="w-5 h-5" />,
      description: 'Basic system configuration'
    },
    {
      id: 'users',
      title: 'User Management',
      icon: <Users className="w-5 h-5" />,
      description: 'Manage users and permissions'
    },
    {
      id: 'security',
      title: 'Security & Privacy',
      icon: <Shield className="w-5 h-5" />,
      description: 'Security and privacy settings'
    },
    {
      id: 'notifications',
      title: 'Notifications',
      icon: <Bell className="w-5 h-5" />,
      description: 'Configure notification preferences'
    },
    {
      id: 'integrations',
      title: 'Integrations',
      icon: <Database className="w-5 h-5" />,
      description: 'Third-party integrations'
    },
    {
      id: 'billing',
      title: 'Billing & Plans',
      icon: <CreditCard className="w-5 h-5" />,
      description: 'Subscription and billing'
    }
  ]

  const renderGeneralSettings = () => (
    <div className="space-y-6">
      <Card className="p-6">
        <h3 className="text-lg font-semibold text-foreground mb-4">Company Information</h3>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div>
            <label className="block text-sm font-medium text-foreground mb-2">Company Name</label>
            <input
              type="text"
              defaultValue="TechCorp Inc."
              className="w-full border border-input rounded-lg px-3 py-2 text-sm bg-background focus:outline-none focus:ring-2 focus:ring-ring focus:border-transparent"
            />
          </div>
          <div>
            <label className="block text-sm font-medium text-foreground mb-2">Industry</label>
            <select className="w-full border border-input rounded-lg px-3 py-2 text-sm bg-background focus:outline-none focus:ring-2 focus:ring-ring focus:border-transparent">
              <option>Technology</option>
              <option>Healthcare</option>
              <option>Finance</option>
              <option>Manufacturing</option>
            </select>
          </div>
          <div>
            <label className="block text-sm font-medium text-foreground mb-2">Time Zone</label>
            <select className="w-full border border-input rounded-lg px-3 py-2 text-sm bg-background focus:outline-none focus:ring-2 focus:ring-ring focus:border-transparent">
              <option>UTC-8 (Pacific)</option>
              <option>UTC-5 (Eastern)</option>
              <option>UTC+0 (GMT)</option>
              <option>UTC+1 (CET)</option>
            </select>
          </div>
          <div>
            <label className="block text-sm font-medium text-foreground mb-2">Currency</label>
            <select className="w-full border border-input rounded-lg px-3 py-2 text-sm bg-background focus:outline-none focus:ring-2 focus:ring-ring focus:border-transparent">
              <option>USD ($)</option>
              <option>EUR (€)</option>
              <option>GBP (£)</option>
              <option>JPY (¥)</option>
            </select>
          </div>
        </div>
      </Card>

      <Card className="p-6">
        <h3 className="text-lg font-semibold text-foreground mb-4">Travel Policies</h3>
        <div className="space-y-4">
          <div className="flex items-center justify-between">
            <div>
              <p className="font-medium text-foreground">Advance Booking Requirement</p>
              <p className="text-sm text-muted-foreground">Minimum days before travel</p>
            </div>
            <input
              type="number"
              defaultValue="14"
              className="w-20 border border-input rounded-lg px-3 py-2 text-sm bg-background focus:outline-none focus:ring-2 focus:ring-ring focus:border-transparent"
            />
          </div>
          
          <div className="flex items-center justify-between">
            <div>
              <p className="font-medium text-foreground">Maximum Trip Budget</p>
              <p className="text-sm text-muted-foreground">Default limit per trip</p>
            </div>
            <input
              type="number"
              defaultValue="5000"
              className="w-24 border border-input rounded-lg px-3 py-2 text-sm bg-background focus:outline-none focus:ring-2 focus:ring-ring focus:border-transparent"
            />
          </div>
          
          <div className="flex items-center justify-between">
            <div>
              <p className="font-medium text-foreground">Approval Required</p>
              <p className="text-sm text-muted-foreground">Trips above threshold require approval</p>
            </div>
            <input
              type="checkbox"
              defaultChecked
              className="w-5 h-5 border border-input rounded focus:outline-none focus:ring-2 focus:ring-ring"
            />
          </div>
        </div>
      </Card>
    </div>
  )

  const renderNotificationSettings = () => (
    <div className="space-y-6">
      <Card className="p-6">
        <h3 className="text-lg font-semibold text-foreground mb-4">Notification Channels</h3>
        <div className="space-y-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-3">
              <Mail className="w-5 h-5 text-muted-foreground" />
              <div>
                <p className="font-medium text-foreground">Email Notifications</p>
                <p className="text-sm text-muted-foreground">Receive updates via email</p>
              </div>
            </div>
            <input
              type="checkbox"
              checked={notifications.email}
              onChange={(e) => setNotifications({...notifications, email: e.target.checked})}
              className="w-5 h-5 border border-input rounded focus:outline-none focus:ring-2 focus:ring-ring"
            />
          </div>
          
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-3">
              <Smartphone className="w-5 h-5 text-muted-foreground" />
              <div>
                <p className="font-medium text-foreground">SMS Notifications</p>
                <p className="text-sm text-muted-foreground">Receive updates via SMS</p>
              </div>
            </div>
            <input
              type="checkbox"
              checked={notifications.sms}
              onChange={(e) => setNotifications({...notifications, sms: e.target.checked})}
              className="w-5 h-5 border border-input rounded focus:outline-none focus:ring-2 focus:ring-ring"
            />
          </div>
          
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-3">
              <Bell className="w-5 h-5 text-muted-foreground" />
              <div>
                <p className="font-medium text-foreground">Push Notifications</p>
                <p className="text-sm text-muted-foreground">Browser push notifications</p>
              </div>
            </div>
            <input
              type="checkbox"
              checked={notifications.push}
              onChange={(e) => setNotifications({...notifications, push: e.target.checked})}
              className="w-5 h-5 border border-input rounded focus:outline-none focus:ring-2 focus:ring-ring"
            />
          </div>
        </div>
      </Card>

      <Card className="p-6">
        <h3 className="text-lg font-semibold text-foreground mb-4">Notification Types</h3>
        <div className="space-y-4">
          <div className="flex items-center justify-between">
            <div>
              <p className="font-medium text-foreground">Booking Confirmations</p>
              <p className="text-sm text-muted-foreground">New bookings and updates</p>
            </div>
            <input
              type="checkbox"
              checked={notifications.booking}
              onChange={(e) => setNotifications({...notifications, booking: e.target.checked})}
              className="w-5 h-5 border border-input rounded focus:outline-none focus:ring-2 focus:ring-ring"
            />
          </div>
          
          <div className="flex items-center justify-between">
            <div>
              <p className="font-medium text-foreground">Approval Requests</p>
              <p className="text-sm text-muted-foreground">Pending approvals</p>
            </div>
            <input
              type="checkbox"
              checked={notifications.approval}
              onChange={(e) => setNotifications({...notifications, approval: e.target.checked})}
              className="w-5 h-5 border border-input rounded focus:outline-none focus:ring-2 focus:ring-ring"
            />
          </div>
          
          <div className="flex items-center justify-between">
            <div>
              <p className="font-medium text-foreground">Policy Violations</p>
              <p className="text-sm text-muted-foreground">Policy compliance alerts</p>
            </div>
            <input
              type="checkbox"
              checked={notifications.policy}
              onChange={(e) => setNotifications({...notifications, policy: e.target.checked})}
              className="w-5 h-5 border border-input rounded focus:outline-none focus:ring-2 focus:ring-ring"
            />
          </div>
        </div>
      </Card>
    </div>
  )

  const renderIntegrationSettings = () => (
    <div className="space-y-6">
      <Card className="p-6">
        <h3 className="text-lg font-semibold text-foreground mb-4">API Configuration</h3>
        <div className="space-y-4">
          <div>
            <label className="block text-sm font-medium text-foreground mb-2">API Key</label>
            <div className="flex items-center space-x-2">
              <input
                type={showApiKey ? 'text' : 'password'}
                value="sk_live_1234567890abcdef..."
                readOnly
                className="flex-1 border border-input rounded-lg px-3 py-2 text-sm bg-muted font-mono"
              />
              <Button
                variant="outline"
                size="sm"
                onClick={() => setShowApiKey(!showApiKey)}
              >
                {showApiKey ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
              </Button>
              <Button variant="outline" size="sm">
                <RefreshCw className="w-4 h-4" />
              </Button>
            </div>
          </div>
          
          <div>
            <label className="block text-sm font-medium text-foreground mb-2">Webhook URL</label>
            <input
              type="url"
              placeholder="https://your-domain.com/webhooks/travel"
              className="w-full border border-input rounded-lg px-3 py-2 text-sm bg-background focus:outline-none focus:ring-2 focus:ring-ring focus:border-transparent"
            />
          </div>
        </div>
      </Card>

      <Card className="p-6">
        <h3 className="text-lg font-semibold text-foreground mb-4">Connected Services</h3>
        <div className="space-y-4">
          <div className="flex items-center justify-between p-4 border border-border rounded-lg">
            <div className="flex items-center space-x-3">
              <div className="w-10 h-10 bg-blue-100 rounded-lg flex items-center justify-center">
                <Globe className="w-5 h-5 text-blue-600" />
              </div>
              <div>
                <p className="font-medium text-foreground">Expedia Partner Solutions</p>
                <p className="text-sm text-muted-foreground">Flight and hotel booking integration</p>
              </div>
            </div>
            <div className="flex items-center space-x-2">
              <span className="status-badge status-approved">Connected</span>
              <Button variant="outline" size="sm">Configure</Button>
            </div>
          </div>
          
          <div className="flex items-center justify-between p-4 border border-border rounded-lg">
            <div className="flex items-center space-x-3">
              <div className="w-10 h-10 bg-green-100 rounded-lg flex items-center justify-center">
                <CreditCard className="w-5 h-5 text-green-600" />
              </div>
              <div>
                <p className="font-medium text-foreground">Concur Expense</p>
                <p className="text-sm text-muted-foreground">Expense management integration</p>
              </div>
            </div>
            <div className="flex items-center space-x-2">
              <span className="status-badge status-pending">Pending</span>
              <Button variant="outline" size="sm">Setup</Button>
            </div>
          </div>
          
          <div className="flex items-center justify-between p-4 border border-border rounded-lg">
            <div className="flex items-center space-x-3">
              <div className="w-10 h-10 bg-gray-100 rounded-lg flex items-center justify-center">
                <Lock className="w-5 h-5 text-gray-600" />
              </div>
              <div>
                <p className="font-medium text-foreground">Active Directory</p>
                <p className="text-sm text-muted-foreground">SSO and user management</p>
              </div>
            </div>
            <div className="flex items-center space-x-2">
              <span className="status-badge bg-gray-100 text-gray-800">Not Connected</span>
              <Button variant="outline" size="sm">Connect</Button>
            </div>
          </div>
        </div>
      </Card>
    </div>
  )

  const renderCurrentSection = () => {
    switch (activeSection) {
      case 'general':
        return renderGeneralSettings()
      case 'notifications':
        return renderNotificationSettings()
      case 'integrations':
        return renderIntegrationSettings()
      case 'users':
        return (
          <Card className="p-12 text-center">
            <Users className="w-16 h-16 mx-auto mb-4 text-muted-foreground" />
            <h3 className="text-lg font-semibold text-foreground mb-2">User Management</h3>
            <p className="text-muted-foreground">Manage user accounts, roles, and permissions</p>
          </Card>
        )
      case 'security':
        return (
          <Card className="p-12 text-center">
            <Shield className="w-16 h-16 mx-auto mb-4 text-muted-foreground" />
            <h3 className="text-lg font-semibold text-foreground mb-2">Security & Privacy</h3>
            <p className="text-muted-foreground">Configure security settings and privacy controls</p>
          </Card>
        )
      case 'billing':
        return (
          <Card className="p-12 text-center">
            <CreditCard className="w-16 h-16 mx-auto mb-4 text-muted-foreground" />
            <h3 className="text-lg font-semibold text-foreground mb-2">Billing & Plans</h3>
            <p className="text-muted-foreground">Manage your subscription and billing information</p>
          </Card>
        )
      default:
        return renderGeneralSettings()
    }
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div>
          <h2 className="text-2xl font-bold text-foreground">System Settings</h2>
          <p className="text-muted-foreground">Configure your enterprise travel management platform</p>
        </div>
        
        <div className="flex items-center gap-3">
          <Button variant="outline">Reset to Defaults</Button>
          <Button className="flex items-center gap-2">
            <Save className="w-4 h-4" />
            Save Changes
          </Button>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-4 gap-6">
        {/* Settings Navigation */}
        <div className="lg:col-span-1">
          <Card className="p-4">
            <nav className="space-y-1">
              {settingSections.map((section) => (
                <button
                  key={section.id}
                  onClick={() => setActiveSection(section.id)}
                  className={`w-full flex items-center space-x-3 px-3 py-2.5 rounded-lg transition-colors text-left ${
                    activeSection === section.id
                      ? 'bg-primary text-primary-foreground'
                      : 'text-muted-foreground hover:text-foreground hover:bg-accent'
                  }`}
                >
                  {section.icon}
                  <div className="flex-1 min-w-0">
                    <p className="text-sm font-medium truncate">{section.title}</p>
                    <p className="text-xs opacity-75 truncate">{section.description}</p>
                  </div>
                </button>
              ))}
            </nav>
          </Card>
        </div>

        {/* Settings Content */}
        <div className="lg:col-span-3">
          {renderCurrentSection()}
        </div>
      </div>
    </div>
  )
}