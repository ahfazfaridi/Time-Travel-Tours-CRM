import React from 'react'
import { 
  TrendingUp, 
  Users, 
  Calendar, 
  DollarSign, 
  Plane,
  MapPin,
  Clock,
  AlertTriangle
} from 'lucide-react'
import { Card } from '../ui/card'

interface KPICardProps {
  title: string
  value: string
  change: string
  trend: 'up' | 'down'
  icon: React.ReactNode
}

const KPICard: React.FC<KPICardProps> = ({ title, value, change, trend, icon }) => (
  <Card className="p-6 hover:shadow-lg transition-shadow duration-200">
    <div className="flex items-center justify-between">
      <div>
        <p className="text-sm font-medium text-muted-foreground">{title}</p>
        <p className="text-2xl font-bold text-foreground mt-1">{value}</p>
        <div className="flex items-center mt-2">
          <TrendingUp className={`w-4 h-4 mr-1 ${
            trend === 'up' ? 'text-corporate-success' : 'text-corporate-danger'
          }`} />
          <span className={`text-sm font-medium ${
            trend === 'up' ? 'text-corporate-success' : 'text-corporate-danger'
          }`}>
            {change}
          </span>
          <span className="text-sm text-muted-foreground ml-1">vs last month</span>
        </div>
      </div>
      <div className="w-12 h-12 enterprise-gradient rounded-lg flex items-center justify-center">
        {icon}
      </div>
    </div>
  </Card>
)

interface RecentBookingProps {
  id: string
  traveler: string
  destination: string
  date: string
  status: 'approved' | 'pending' | 'rejected'
  amount: string
}

const RecentBooking: React.FC<RecentBookingProps> = ({ 
  id, traveler, destination, date, status, amount 
}) => (
  <div className="flex items-center justify-between p-4 border border-border rounded-lg hover:bg-accent/50 transition-colors">
    <div className="flex items-center space-x-3">
      <div className="w-10 h-10 bg-primary/10 rounded-lg flex items-center justify-center">
        <Plane className="w-5 h-5 text-primary" />
      </div>
      <div>
        <p className="font-medium text-foreground">{traveler}</p>
        <div className="flex items-center space-x-2 text-sm text-muted-foreground">
          <MapPin className="w-3 h-3" />
          <span>{destination}</span>
          <span>•</span>
          <Clock className="w-3 h-3" />
          <span>{date}</span>
        </div>
      </div>
    </div>
    <div className="text-right">
      <p className="font-semibold text-foreground">{amount}</p>
      <span className={`status-badge ${
        status === 'approved' ? 'status-approved' : 
        status === 'pending' ? 'status-pending' : 'status-rejected'
      }`}>
        {status.charAt(0).toUpperCase() + status.slice(1)}
      </span>
    </div>
  </div>
)

export const Dashboard: React.FC = () => {
  console.log('Dashboard component rendering')

  const kpiData = [
    {
      title: 'Total Bookings',
      value: '1,247',
      change: '+12.5%',
      trend: 'up' as const,
      icon: <Calendar className="w-6 h-6 text-white" />
    },
    {
      title: 'Active Travelers',
      value: '342',
      change: '+8.2%',
      trend: 'up' as const,
      icon: <Users className="w-6 h-6 text-white" />
    },
    {
      title: 'Travel Spend',
      value: '$89.2K',
      change: '-3.1%',
      trend: 'down' as const,
      icon: <DollarSign className="w-6 h-6 text-white" />
    },
    {
      title: 'Avg. Trip Cost',
      value: '$2,340',
      change: '+5.7%',
      trend: 'up' as const,
      icon: <TrendingUp className="w-6 h-6 text-white" />
    }
  ]

  const recentBookings = [
    {
      id: 'BK-001',
      traveler: 'Sarah Johnson',
      destination: 'New York → London',
      date: 'Dec 15, 2024',
      status: 'approved' as const,
      amount: '$2,840'
    },
    {
      id: 'BK-002',
      traveler: 'Michael Chen',
      destination: 'San Francisco → Tokyo',
      date: 'Dec 18, 2024',
      status: 'pending' as const,
      amount: '$3,250'
    },
    {
      id: 'BK-003',
      traveler: 'Emily Davis',
      destination: 'Chicago → Paris',
      date: 'Dec 20, 2024',
      status: 'approved' as const,
      amount: '$2,150'
    },
    {
      id: 'BK-004',
      traveler: 'David Wilson',
      destination: 'Boston → Berlin',
      date: 'Dec 22, 2024',
      status: 'rejected' as const,
      amount: '$1,890'
    }
  ]

  return (
    <div className="space-y-6">
      {/* KPI Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        {kpiData.map((kpi, index) => (
          <KPICard key={index} {...kpi} />
        ))}
      </div>

      {/* Main Content Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Recent Bookings */}
        <div className="lg:col-span-2">
          <Card className="p-6">
            <div className="flex items-center justify-between mb-6">
              <h3 className="text-lg font-semibold text-foreground">Recent Bookings</h3>
              <button className="text-sm text-primary hover:text-primary/80 font-medium">
                View All
              </button>
            </div>
            <div className="space-y-4">
              {recentBookings.map((booking) => (
                <RecentBooking key={booking.id} {...booking} />
              ))}
            </div>
          </Card>
        </div>

        {/* Quick Actions & Alerts */}
        <div className="space-y-6">
          {/* Quick Actions */}
          <Card className="p-6">
            <h3 className="text-lg font-semibold text-foreground mb-4">Quick Actions</h3>
            <div className="space-y-3">
              <button className="w-full p-3 text-left rounded-lg border border-border hover:bg-accent transition-colors">
                <div className="flex items-center space-x-3">
                  <div className="w-8 h-8 bg-primary/10 rounded-lg flex items-center justify-center">
                    <Calendar className="w-4 h-4 text-primary" />
                  </div>
                  <div>
                    <p className="font-medium text-foreground">New Booking</p>
                    <p className="text-sm text-muted-foreground">Create travel request</p>
                  </div>
                </div>
              </button>
              
              <button className="w-full p-3 text-left rounded-lg border border-border hover:bg-accent transition-colors">
                <div className="flex items-center space-x-3">
                  <div className="w-8 h-8 bg-primary/10 rounded-lg flex items-center justify-center">
                    <Users className="w-4 h-4 text-primary" />
                  </div>
                  <div>
                    <p className="font-medium text-foreground">Add Traveler</p>
                    <p className="text-sm text-muted-foreground">Register new employee</p>
                  </div>
                </div>
              </button>
              
              <button className="w-full p-3 text-left rounded-lg border border-border hover:bg-accent transition-colors">
                <div className="flex items-center space-x-3">
                  <div className="w-8 h-8 bg-primary/10 rounded-lg flex items-center justify-center">
                    <MapPin className="w-4 h-4 text-primary" />
                  </div>
                  <div>
                    <p className="font-medium text-foreground">Plan Itinerary</p>
                    <p className="text-sm text-muted-foreground">Create travel plan</p>
                  </div>
                </div>
              </button>
            </div>
          </Card>

          {/* Alerts */}
          <Card className="p-6">
            <h3 className="text-lg font-semibold text-foreground mb-4">System Alerts</h3>
            <div className="space-y-3">
              <div className="p-3 rounded-lg bg-yellow-50 border border-yellow-200">
                <div className="flex items-start space-x-2">
                  <AlertTriangle className="w-4 h-4 text-yellow-600 mt-0.5" />
                  <div>
                    <p className="text-sm font-medium text-yellow-800">Policy Violation</p>
                    <p className="text-xs text-yellow-700 mt-1">
                      3 bookings exceed budget limits
                    </p>
                  </div>
                </div>
              </div>
              
              <div className="p-3 rounded-lg bg-blue-50 border border-blue-200">
                <div className="flex items-start space-x-2">
                  <Clock className="w-4 h-4 text-blue-600 mt-0.5" />
                  <div>
                    <p className="text-sm font-medium text-blue-800">Pending Approvals</p>
                    <p className="text-xs text-blue-700 mt-1">
                      8 travel requests awaiting review
                    </p>
                  </div>
                </div>
              </div>
            </div>
          </Card>
        </div>
      </div>
    </div>
  )
}