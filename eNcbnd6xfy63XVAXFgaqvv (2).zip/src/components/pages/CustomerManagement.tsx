import React, { useState } from 'react'
import { 
  Search, 
  Plus, 
  User, 
  Mail, 
  Phone, 
  MapPin, 
  Calendar,
  Building,
  CreditCard,
  TrendingUp,
  Filter,
  MoreVertical
} from 'lucide-react'
import { Card } from '../ui/card'
import { Button } from '../ui/button'

interface Customer {
  id: string
  name: string
  email: string
  phone: string
  company: string
  department: string
  position: string
  totalBookings: number
  totalSpent: number
  lastTravel: string
  preferredDestinations: string[]
  status: 'active' | 'inactive' | 'vip'
  joinDate: string
}

export const CustomerManagement: React.FC = () => {
  const [searchTerm, setSearchTerm] = useState('')
  const [statusFilter, setStatusFilter] = useState('all')

  console.log('CustomerManagement rendering with search:', searchTerm)

  const customers: Customer[] = [
    {
      id: 'CU-001',
      name: 'Sarah Johnson',
      email: 'sarah.johnson@techcorp.com',
      phone: '+1 (555) 123-4567',
      company: 'TechCorp Inc.',
      department: 'Engineering',
      position: 'Senior Software Engineer',
      totalBookings: 12,
      totalSpent: 34200,
      lastTravel: '2024-11-15',
      preferredDestinations: ['London', 'Tokyo', 'Berlin'],
      status: 'vip',
      joinDate: '2023-03-15'
    },
    {
      id: 'CU-002',
      name: 'Michael Chen',
      email: 'michael.chen@techcorp.com',
      phone: '+1 (555) 234-5678',
      company: 'TechCorp Inc.',
      department: 'Sales',
      position: 'Sales Director',
      totalBookings: 18,
      totalSpent: 45600,
      lastTravel: '2024-12-02',
      preferredDestinations: ['New York', 'Singapore', 'Sydney'],
      status: 'vip',
      joinDate: '2022-08-20'
    },
    {
      id: 'CU-003',
      name: 'Emily Davis',
      email: 'emily.davis@innovate.com',
      phone: '+1 (555) 345-6789',
      company: 'Innovate Solutions',
      department: 'Marketing',
      position: 'Marketing Manager',
      totalBookings: 8,
      totalSpent: 18400,
      lastTravel: '2024-10-28',
      preferredDestinations: ['Paris', 'Milan', 'Barcelona'],
      status: 'active',
      joinDate: '2023-11-10'
    },
    {
      id: 'CU-004',
      name: 'David Wilson',
      email: 'david.wilson@globaltech.com',
      phone: '+1 (555) 456-7890',
      company: 'GlobalTech Ltd.',
      department: 'Operations',
      position: 'Operations Manager',
      totalBookings: 5,
      totalSpent: 12300,
      lastTravel: '2024-09-15',
      preferredDestinations: ['Amsterdam', 'Frankfurt', 'Zurich'],
      status: 'active',
      joinDate: '2024-01-05'
    },
    {
      id: 'CU-005',
      name: 'Lisa Anderson',
      email: 'lisa.anderson@startupx.com',
      phone: '+1 (555) 567-8901',
      company: 'StartupX',
      department: 'Product',
      position: 'Product Designer',
      totalBookings: 3,
      totalSpent: 7800,
      lastTravel: '2024-08-20',
      preferredDestinations: ['Copenhagen', 'Stockholm', 'Helsinki'],
      status: 'inactive',
      joinDate: '2024-05-12'
    }
  ]

  const getStatusBadgeClass = (status: string) => {
    switch (status) {
      case 'vip':
        return 'status-badge bg-purple-100 text-purple-800'
      case 'active':
        return 'status-badge status-approved'
      case 'inactive':
        return 'status-badge bg-gray-100 text-gray-800'
      default:
        return 'status-badge bg-gray-100 text-gray-800'
    }
  }

  const filteredCustomers = customers.filter(customer => {
    const matchesSearch = customer.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         customer.email.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         customer.company.toLowerCase().includes(searchTerm.toLowerCase())
    const matchesStatus = statusFilter === 'all' || customer.status === statusFilter
    return matchesSearch && matchesStatus
  })

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div>
          <h2 className="text-2xl font-bold text-foreground">Customer Relations</h2>
          <p className="text-muted-foreground">Manage corporate travelers and customer relationships</p>
        </div>
        
        <div className="flex items-center gap-3">
          <Button variant="outline" className="flex items-center gap-2">
            <TrendingUp className="w-4 h-4" />
            Analytics
          </Button>
          <Button className="flex items-center gap-2">
            <Plus className="w-4 h-4" />
            Add Customer
          </Button>
        </div>
      </div>

      {/* Stats Overview */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <Card className="p-4">
          <div className="flex items-center space-x-3">
            <div className="w-10 h-10 bg-blue-100 rounded-lg flex items-center justify-center">
              <User className="w-5 h-5 text-blue-600" />
            </div>
            <div>
              <p className="text-sm text-muted-foreground">Total Customers</p>
              <p className="text-xl font-bold">{customers.length}</p>
            </div>
          </div>
        </Card>
        
        <Card className="p-4">
          <div className="flex items-center space-x-3">
            <div className="w-10 h-10 bg-purple-100 rounded-lg flex items-center justify-center">
              <TrendingUp className="w-5 h-5 text-purple-600" />
            </div>
            <div>
              <p className="text-sm text-muted-foreground">VIP Customers</p>
              <p className="text-xl font-bold">
                {customers.filter(c => c.status === 'vip').length}
              </p>
            </div>
          </div>
        </Card>
        
        <Card className="p-4">
          <div className="flex items-center space-x-3">
            <div className="w-10 h-10 bg-green-100 rounded-lg flex items-center justify-center">
              <Building className="w-5 h-5 text-green-600" />
            </div>
            <div>
              <p className="text-sm text-muted-foreground">Companies</p>
              <p className="text-xl font-bold">
                {Array.from(new Set(customers.map(c => c.company))).length}
              </p>
            </div>
          </div>
        </Card>
        
        <Card className="p-4">
          <div className="flex items-center space-x-3">
            <div className="w-10 h-10 bg-primary/10 rounded-lg flex items-center justify-center">
              <CreditCard className="w-5 h-5 text-primary" />
            </div>
            <div>
              <p className="text-sm text-muted-foreground">Total Revenue</p>
              <p className="text-xl font-bold">
                ${customers.reduce((sum, c) => sum + c.totalSpent, 0).toLocaleString()}
              </p>
            </div>
          </div>
        </Card>
      </div>

      {/* Filters */}
      <Card className="p-6">
        <div className="flex flex-col sm:flex-row gap-4">
          <div className="relative flex-1">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 w-4 h-4 text-muted-foreground" />
            <input
              type="text"
              placeholder="Search customers, companies, emails..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="pl-10 pr-4 py-2 w-full border border-input rounded-lg bg-background text-sm focus:outline-none focus:ring-2 focus:ring-ring focus:border-transparent"
            />
          </div>
          
          <div className="flex items-center gap-3">
            <div className="flex items-center gap-2">
              <Filter className="w-4 h-4 text-muted-foreground" />
              <select
                value={statusFilter}
                onChange={(e) => setStatusFilter(e.target.value)}
                className="border border-input rounded-lg px-3 py-2 text-sm bg-background focus:outline-none focus:ring-2 focus:ring-ring focus:border-transparent"
              >
                <option value="all">All Status</option>
                <option value="vip">VIP</option>
                <option value="active">Active</option>
                <option value="inactive">Inactive</option>
              </select>
            </div>
          </div>
        </div>
      </Card>

      {/* Customer Cards */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {filteredCustomers.map((customer) => (
          <Card key={customer.id} className="p-6 hover:shadow-lg transition-shadow">
            <div className="flex items-start justify-between mb-4">
              <div className="flex items-center space-x-3">
                <div className="w-12 h-12 enterprise-gradient rounded-full flex items-center justify-center">
                  <span className="text-white font-semibold">
                    {customer.name.split(' ').map(n => n[0]).join('')}
                  </span>
                </div>
                <div>
                  <h3 className="font-semibold text-foreground">{customer.name}</h3>
                  <p className="text-sm text-muted-foreground">{customer.position}</p>
                  <span className={getStatusBadgeClass(customer.status)}>
                    {customer.status.toUpperCase()}
                  </span>
                </div>
              </div>
              <Button variant="ghost" size="sm">
                <MoreVertical className="w-4 h-4" />
              </Button>
            </div>

            <div className="space-y-3">
              <div className="flex items-center space-x-2 text-sm">
                <Building className="w-4 h-4 text-muted-foreground" />
                <span>{customer.company}</span>
                <span className="text-muted-foreground">•</span>
                <span className="text-muted-foreground">{customer.department}</span>
              </div>
              
              <div className="flex items-center space-x-2 text-sm">
                <Mail className="w-4 h-4 text-muted-foreground" />
                <span>{customer.email}</span>
              </div>
              
              <div className="flex items-center space-x-2 text-sm">
                <Phone className="w-4 h-4 text-muted-foreground" />
                <span>{customer.phone}</span>
              </div>
              
              <div className="flex items-center space-x-2 text-sm">
                <MapPin className="w-4 h-4 text-muted-foreground" />
                <span>Preferred: {customer.preferredDestinations.join(', ')}</span>
              </div>
            </div>

            <div className="mt-4 pt-4 border-t border-border">
              <div className="grid grid-cols-3 gap-4 text-center">
                <div>
                  <p className="text-lg font-bold text-foreground">{customer.totalBookings}</p>
                  <p className="text-xs text-muted-foreground">Bookings</p>
                </div>
                <div>
                  <p className="text-lg font-bold text-foreground">
                    ${(customer.totalSpent / 1000).toFixed(0)}K
                  </p>
                  <p className="text-xs text-muted-foreground">Spent</p>
                </div>
                <div>
                  <p className="text-lg font-bold text-foreground">
                    {new Date(customer.lastTravel).toLocaleDateString('en-US', { month: 'short', day: 'numeric' })}
                  </p>
                  <p className="text-xs text-muted-foreground">Last Travel</p>
                </div>
              </div>
            </div>

            <div className="mt-4 flex items-center justify-between">
              <div className="flex items-center space-x-2 text-sm text-muted-foreground">
                <Calendar className="w-4 h-4" />
                <span>Joined {new Date(customer.joinDate).toLocaleDateString()}</span>
              </div>
              <Button size="sm" variant="outline">
                View Profile
              </Button>
            </div>
          </Card>
        ))}
      </div>
    </div>
  )
}