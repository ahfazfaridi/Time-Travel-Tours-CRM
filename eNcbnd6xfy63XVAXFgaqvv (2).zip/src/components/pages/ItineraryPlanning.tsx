import React, { useState } from 'react'
import { 
  Plus, 
  Calendar, 
  MapPin, 
  Clock, 
  Plane,
  Hotel,
  Car,
  Utensils,
  CheckCircle,
  AlertCircle,
  Edit3,
  Trash2,
  Share2
} from 'lucide-react'
import { Card } from '../ui/card'
import { Button } from '../ui/button'

interface ItineraryEvent {
  id: string
  type: 'flight' | 'hotel' | 'meeting' | 'transport' | 'meal' | 'activity'
  title: string
  description?: string
  startTime: string
  endTime?: string
  location: string
  status: 'confirmed' | 'pending' | 'cancelled'
  cost?: number
  notes?: string
}

interface Itinerary {
  id: string
  title: string
  traveler: string
  destination: string
  startDate: string
  endDate: string
  status: 'draft' | 'approved' | 'active' | 'completed'
  events: ItineraryEvent[]
  totalCost: number
  lastModified: string
}

export const ItineraryPlanning: React.FC = () => {
  const [selectedItinerary, setSelectedItinerary] = useState<string | null>(null)
  const [showNewItinerary, setShowNewItinerary] = useState(false)

  console.log('ItineraryPlanning rendering with selected:', selectedItinerary)

  const itineraries: Itinerary[] = [
    {
      id: 'IT-001',
      title: 'London Business Trip',
      traveler: 'Sarah Johnson',
      destination: 'London, UK',
      startDate: '2024-12-15',
      endDate: '2024-12-20',
      status: 'approved',
      totalCost: 2840,
      lastModified: '2024-12-01',
      events: [
        {
          id: 'EV-001',
          type: 'flight',
          title: 'Outbound Flight',
          description: 'JFK → LHR',
          startTime: '2024-12-15T20:00',
          endTime: '2024-12-16T08:30',
          location: 'JFK Airport, Terminal 4',
          status: 'confirmed',
          cost: 850,
          notes: 'Business class, Seat 2A'
        },
        {
          id: 'EV-002',
          type: 'hotel',
          title: 'Hotel Check-in',
          description: 'The Langham London',
          startTime: '2024-12-16T15:00',
          endTime: '2024-12-20T11:00',
          location: '1C Portland Pl, London W1B 1JA',
          status: 'confirmed',
          cost: 1200,
          notes: 'Executive room with city view'
        },
        {
          id: 'EV-003',
          type: 'meeting',
          title: 'Client Meeting',
          description: 'Q4 Strategy Review',
          startTime: '2024-12-17T10:00',
          endTime: '2024-12-17T12:00',
          location: 'Canary Wharf, Tower 42',
          status: 'confirmed'
        },
        {
          id: 'EV-004',
          type: 'flight',
          title: 'Return Flight',
          description: 'LHR → JFK',
          startTime: '2024-12-20T14:00',
          endTime: '2024-12-20T17:30',
          location: 'Heathrow Airport, Terminal 5',
          status: 'confirmed',
          cost: 790
        }
      ]
    },
    {
      id: 'IT-002',
      title: 'Tokyo Conference',
      traveler: 'Michael Chen',
      destination: 'Tokyo, Japan',
      startDate: '2024-12-18',
      endDate: '2024-12-25',
      status: 'draft',
      totalCost: 3250,
      lastModified: '2024-12-02',
      events: [
        {
          id: 'EV-005',
          type: 'flight',
          title: 'Outbound Flight',
          description: 'SFO → NRT',
          startTime: '2024-12-18T11:00',
          endTime: '2024-12-19T15:30',
          location: 'San Francisco International',
          status: 'pending',
          cost: 1400
        },
        {
          id: 'EV-006',
          type: 'hotel',
          title: 'Hotel Reservation',
          description: 'Park Hyatt Tokyo',
          startTime: '2024-12-19T15:00',
          endTime: '2024-12-25T12:00',
          location: 'Shinjuku, Tokyo',
          status: 'pending',
          cost: 1850
        }
      ]
    }
  ]

  const getEventIcon = (type: string) => {
    switch (type) {
      case 'flight':
        return <Plane className="w-4 h-4" />
      case 'hotel':
        return <Hotel className="w-4 h-4" />
      case 'transport':
        return <Car className="w-4 h-4" />
      case 'meal':
        return <Utensils className="w-4 h-4" />
      case 'meeting':
        return <Calendar className="w-4 h-4" />
      default:
        return <MapPin className="w-4 h-4" />
    }
  }

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'confirmed':
        return <CheckCircle className="w-4 h-4 text-green-600" />
      case 'pending':
        return <AlertCircle className="w-4 h-4 text-yellow-600" />
      case 'cancelled':
        return <AlertCircle className="w-4 h-4 text-red-600" />
      default:
        return <AlertCircle className="w-4 h-4 text-gray-600" />
    }
  }

  const getStatusBadgeClass = (status: string) => {
    switch (status) {
      case 'approved':
        return 'status-badge status-approved'
      case 'draft':
        return 'status-badge bg-gray-100 text-gray-800'
      case 'active':
        return 'status-badge bg-blue-100 text-blue-800'
      case 'completed':
        return 'status-badge bg-purple-100 text-purple-800'
      default:
        return 'status-badge bg-gray-100 text-gray-800'
    }
  }

  const selectedItineraryData = itineraries.find(it => it.id === selectedItinerary)

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div>
          <h2 className="text-2xl font-bold text-foreground">Itinerary Planning</h2>
          <p className="text-muted-foreground">Create and manage detailed travel itineraries</p>
        </div>
        
        <div className="flex items-center gap-3">
          <Button variant="outline" className="flex items-center gap-2">
            <Share2 className="w-4 h-4" />
            Share
          </Button>
          <Button 
            className="flex items-center gap-2"
            onClick={() => setShowNewItinerary(true)}
          >
            <Plus className="w-4 h-4" />
            New Itinerary
          </Button>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Itinerary List */}
        <div className="lg:col-span-1">
          <Card className="p-4">
            <h3 className="font-semibold text-foreground mb-4">Active Itineraries</h3>
            <div className="space-y-3">
              {itineraries.map((itinerary) => (
                <div
                  key={itinerary.id}
                  onClick={() => setSelectedItinerary(itinerary.id)}
                  className={`p-4 rounded-lg border cursor-pointer transition-colors ${
                    selectedItinerary === itinerary.id
                      ? 'border-primary bg-primary/5'
                      : 'border-border hover:bg-accent/50'
                  }`}
                >
                  <div className="flex items-start justify-between">
                    <div className="flex-1">
                      <h4 className="font-medium text-foreground">{itinerary.title}</h4>
                      <p className="text-sm text-muted-foreground">{itinerary.traveler}</p>
                      
                      <div className="flex items-center space-x-2 mt-2">
                        <MapPin className="w-3 h-3 text-muted-foreground" />
                        <span className="text-xs text-muted-foreground">{itinerary.destination}</span>
                      </div>
                      
                      <div className="flex items-center space-x-2 mt-1">
                        <Calendar className="w-3 h-3 text-muted-foreground" />
                        <span className="text-xs text-muted-foreground">
                          {new Date(itinerary.startDate).toLocaleDateString()} - {new Date(itinerary.endDate).toLocaleDateString()}
                        </span>
                      </div>
                    </div>
                    
                    <span className={getStatusBadgeClass(itinerary.status)}>
                      {itinerary.status.charAt(0).toUpperCase() + itinerary.status.slice(1)}
                    </span>
                  </div>
                  
                  <div className="flex items-center justify-between mt-3 pt-3 border-t border-border">
                    <div className="text-sm">
                      <span className="font-medium">${itinerary.totalCost.toLocaleString()}</span>
                      <span className="text-muted-foreground ml-1">total</span>
                    </div>
                    <div className="text-xs text-muted-foreground">
                      {itinerary.events.length} events
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </Card>
        </div>

        {/* Itinerary Details */}
        <div className="lg:col-span-2">
          {selectedItineraryData ? (
            <div className="space-y-6">
              {/* Itinerary Header */}
              <Card className="p-6">
                <div className="flex items-start justify-between">
                  <div>
                    <h3 className="text-xl font-bold text-foreground">{selectedItineraryData.title}</h3>
                    <p className="text-muted-foreground">{selectedItineraryData.traveler}</p>
                    
                    <div className="flex items-center space-x-4 mt-3">
                      <div className="flex items-center space-x-2">
                        <MapPin className="w-4 h-4 text-muted-foreground" />
                        <span className="text-sm">{selectedItineraryData.destination}</span>
                      </div>
                      <div className="flex items-center space-x-2">
                        <Calendar className="w-4 h-4 text-muted-foreground" />
                        <span className="text-sm">
                          {new Date(selectedItineraryData.startDate).toLocaleDateString()} - {new Date(selectedItineraryData.endDate).toLocaleDateString()}
                        </span>
                      </div>
                    </div>
                  </div>
                  
                  <div className="flex items-center space-x-3">
                    <span className={getStatusBadgeClass(selectedItineraryData.status)}>
                      {selectedItineraryData.status.charAt(0).toUpperCase() + selectedItineraryData.status.slice(1)}
                    </span>
                    <Button variant="outline" size="sm">
                      <Edit3 className="w-4 h-4" />
                    </Button>
                  </div>
                </div>
              </Card>

              {/* Timeline */}
              <Card className="p-6">
                <div className="flex items-center justify-between mb-6">
                  <h4 className="text-lg font-semibold text-foreground">Timeline</h4>
                  <Button size="sm" className="flex items-center gap-2">
                    <Plus className="w-4 h-4" />
                    Add Event
                  </Button>
                </div>
                
                <div className="space-y-4">
                  {selectedItineraryData.events.map((event, index) => (
                    <div key={event.id} className="flex items-start space-x-4">
                      <div className="flex flex-col items-center">
                        <div className="w-10 h-10 bg-primary/10 rounded-full flex items-center justify-center">
                          {getEventIcon(event.type)}
                        </div>
                        {index < selectedItineraryData.events.length - 1 && (
                          <div className="w-px h-12 bg-border mt-2"></div>
                        )}
                      </div>
                      
                      <div className="flex-1 pb-8">
                        <div className="flex items-start justify-between">
                          <div>
                            <div className="flex items-center space-x-2">
                              <h5 className="font-medium text-foreground">{event.title}</h5>
                              {getStatusIcon(event.status)}
                            </div>
                            {event.description && (
                              <p className="text-sm text-muted-foreground mt-1">{event.description}</p>
                            )}
                            
                            <div className="flex items-center space-x-4 mt-2 text-sm text-muted-foreground">
                              <div className="flex items-center space-x-1">
                                <Clock className="w-3 h-3" />
                                <span>
                                  {new Date(event.startTime).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                                  {event.endTime && ` - ${new Date(event.endTime).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}`}
                                </span>
                              </div>
                              <div className="flex items-center space-x-1">
                                <MapPin className="w-3 h-3" />
                                <span>{event.location}</span>
                              </div>
                            </div>
                            
                            {event.notes && (
                              <p className="text-xs text-muted-foreground mt-2 bg-accent/50 p-2 rounded">
                                {event.notes}
                              </p>
                            )}
                          </div>
                          
                          <div className="flex items-center space-x-2">
                            {event.cost && (
                              <span className="text-sm font-medium">${event.cost.toLocaleString()}</span>
                            )}
                            <Button variant="ghost" size="sm">
                              <Edit3 className="w-3 h-3" />
                            </Button>
                            <Button variant="ghost" size="sm" className="text-red-600 hover:text-red-700">
                              <Trash2 className="w-3 h-3" />
                            </Button>
                          </div>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </Card>

              {/* Cost Summary */}
              <Card className="p-6">
                <h4 className="text-lg font-semibold text-foreground mb-4">Cost Breakdown</h4>
                <div className="space-y-3">
                  {selectedItineraryData.events
                    .filter(event => event.cost)
                    .map((event) => (
                      <div key={event.id} className="flex items-center justify-between">
                        <div className="flex items-center space-x-2">
                          {getEventIcon(event.type)}
                          <span className="text-sm">{event.title}</span>
                        </div>
                        <span className="font-medium">${event.cost!.toLocaleString()}</span>
                      </div>
                    ))}
                  
                  <div className="pt-3 border-t border-border">
                    <div className="flex items-center justify-between">
                      <span className="font-semibold">Total Cost</span>
                      <span className="text-lg font-bold text-primary">
                        ${selectedItineraryData.totalCost.toLocaleString()}
                      </span>
                    </div>
                  </div>
                </div>
              </Card>
            </div>
          ) : (
            <Card className="p-12 text-center">
              <div className="w-16 h-16 bg-primary/10 rounded-full flex items-center justify-center mx-auto mb-4">
                <Calendar className="w-8 h-8 text-primary" />
              </div>
              <h3 className="text-lg font-semibold text-foreground mb-2">Select an Itinerary</h3>
              <p className="text-muted-foreground mb-6">
                Choose an itinerary from the list to view and edit its details
              </p>
              <Button onClick={() => setShowNewItinerary(true)}>
                Create New Itinerary
              </Button>
            </Card>
          )}
        </div>
      </div>
    </div>
  )
}