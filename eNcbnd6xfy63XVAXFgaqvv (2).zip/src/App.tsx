import React, { useState } from 'react'
import { Sidebar } from './components/layout/Sidebar'
import { Header } from './components/layout/Header'
import { Dashboard } from './components/pages/Dashboard'
import { BookingManagement } from './components/pages/BookingManagement'
import { CustomerManagement } from './components/pages/CustomerManagement'
import { ItineraryPlanning } from './components/pages/ItineraryPlanning'
import { Analytics } from './components/pages/Analytics'
import { Settings } from './components/pages/Settings'

export type NavigationPage = 'dashboard' | 'bookings' | 'customers' | 'itineraries' | 'analytics' | 'settings'

function App() {
  const [currentPage, setCurrentPage] = useState<NavigationPage>('dashboard')
  const [sidebarCollapsed, setSidebarCollapsed] = useState(false)

  console.log('App rendering with current page:', currentPage)

  const renderCurrentPage = () => {
    switch (currentPage) {
      case 'dashboard':
        return <Dashboard />
      case 'bookings':
        return <BookingManagement />
      case 'customers':
        return <CustomerManagement />
      case 'itineraries':
        return <ItineraryPlanning />
      case 'analytics':
        return <Analytics />
      case 'settings':
        return <Settings />
      default:
        return <Dashboard />
    }
  }

  return (
    <div className="min-h-screen bg-background">
      <div className="flex">
        <Sidebar 
          currentPage={currentPage}
          onPageChange={setCurrentPage}
          collapsed={sidebarCollapsed}
          onToggleCollapse={() => setSidebarCollapsed(!sidebarCollapsed)}
        />
        
        <div className={`flex-1 transition-all duration-300 ${sidebarCollapsed ? 'ml-16' : 'ml-64'}`}>
          <Header 
            onToggleSidebar={() => setSidebarCollapsed(!sidebarCollapsed)}
            currentPage={currentPage}
          />
          
          <main className="p-6">
            <div className="animate-fade-in">
              {renderCurrentPage()}
            </div>
          </main>
        </div>
      </div>
    </div>
  )
}

export default App